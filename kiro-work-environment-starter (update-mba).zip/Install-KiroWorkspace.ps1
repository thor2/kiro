#Requires -Version 5.1
[CmdletBinding(SupportsShouldProcess)]
param(
    [ValidatePattern('^[A-Za-z]:?$')]
    [string]$DriveLetter = 'C',

    [ValidateNotNullOrEmpty()]
    [string]$Folder = 'KiroWorkspace'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$drive = [System.IO.DriveInfo]::new($DriveLetter.TrimEnd(':'))
if (-not $drive.IsReady -or $drive.DriveType -ne [System.IO.DriveType]::Fixed) {
    throw 'Choose an available fixed local drive.'
}

$segments = $Folder -split '[\\/]'
foreach ($segment in $segments) {
    if ([string]::IsNullOrWhiteSpace($segment) -or
        $segment.EndsWith('.') -or $segment.EndsWith(' ') -or
        $segment.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0 -or
        $segment -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\.|$)' -or
        $segment -match '^OneDrive( - .+)?$') {
        throw 'Use a normal relative folder path outside OneDrive, for example Work\KiroWorkspace.'
    }
}

$destination = Join-Path $drive.RootDirectory.FullName $Folder
$parent = [System.IO.Path]::GetDirectoryName($destination)
if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
    throw "Create the parent folder first: $parent"
}
for ($directory = (Get-Item -LiteralPath $parent -Force); $null -ne $directory; $directory = $directory.Parent) {
    if ($directory.Attributes -band [System.IO.FileAttributes]::ReparsePoint) {
        throw "Choose a destination without a junction, symbolic link or redirected parent: $($directory.FullName)"
    }
}
if (Test-Path -LiteralPath $destination) {
    throw "Destination already exists. Choose a new folder to preserve existing files: $destination"
}

$payload = @('.kiro', 'projects', 'README.md')
foreach ($name in $payload) {
    if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot $name))) {
        throw "Package file or folder missing: $name. Extract the full ZIP before running this script."
    }
}
if (-not $PSCmdlet.ShouldProcess($destination, 'Install Kiro workspace')) {
    return
}

$staging = Join-Path $parent ('.kiro-install-' + [Guid]::NewGuid().ToString('N'))
try {
    [System.IO.Directory]::CreateDirectory($staging) | Out-Null
    foreach ($name in $payload) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $staging -Recurse -Force
    }
    [System.IO.Directory]::Move($staging, $destination)
}
finally {
    if (Test-Path -LiteralPath $staging) {
        Remove-Item -LiteralPath $staging -Recurse -Force -Confirm:$false
    }
}

Write-Output "Installed Kiro workspace: $destination"
