# Workflow standards
1. Confirm project name and scope of run.
2. Identify local input files and record date/filename.
3. Extract facts versus inference. Status values: PROPOSED, UNCONFIRMED, CONFIRMED, SUPERSEDED, BLOCKED.
4. Compare with decision register and action register. Present conflicts without resolving.
5. Draft proposed document changes with old/new text and rationale.
6. Request independent quality review.
7. Produce `proposals/<run-id>/review.md`, a manifest and deliverables. Do not touch originals.
8. Request explicit approval to promote each named deliverable; verify on disk before stating success.

Source tracking minimum: meeting date and source filename. For optional higher assurance include section/page/timestamp when available.

## Advisor and MOU handoffs

Use advisory-handoff.md for the advisory decision status. Existing register status values describe the evidence or register lifecycle. A CONFIRMED meeting decision is not automatically a formally approved amendment. Preserve both meanings when transferring a record. A quality PASS supports review readiness only.

MOU UPDATE prepares a clause proposal with current text, proposed text, rationale, evidence, status and open items. Ask before writing a review package, and stage it only under the selected project's proposals folder. This workflow does not edit or promote the MOU. After explicit approval of the exact wording, apply the change in a separate Word working copy with Track Changes. Formal MOU approval follows the existing decision authority.
