---
inclusion: manual
---

# Advisory handoff

For each decision item, use this Markdown field order. Use Unknown for missing evidence.

- Project
- Decision under review
- Verified requirements and applicability
- Recommendation and confidence
- Decision owner or authority
- Decision status
- Sources, including meeting date and filename for meeting evidence
- Conflicts, unknowns and unresolved questions
- Permitted next step

Decision statuses:

- Proposed: a suggestion or advisor recommendation.
- Agreed in principle: evidence of agreement on direction, with drafting or formal authorization still unverified.
- Approved for drafting: an authorized person approved preparing draft language.
- Formally approved: evidence of the applicable authority's formal decision. Identify its scope.
- Unclear: evidence is incomplete or conflicting.

The permitted next step reflects the source evidence and the user's explicit instruction. Use review-only or clarification when authority is unclear. A request for proposed wording for review does not authorize editing, promotion or formal approval. A receiving agent must preserve the status and source, and pause when a conflict affects the requested action. Carry only the authorized information the receiving workflow needs.
