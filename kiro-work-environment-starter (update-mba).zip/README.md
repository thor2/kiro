# Kiro work environment starter

## 1. Install on your work PC

Extract the full ZIP. Open Windows PowerShell 5.1 or later in the extracted folder. Choose a local fixed drive and a relative folder outside OneDrive. The parent folder must exist and the final folder must be new.

```powershell
.\Install-KiroWorkspace.ps1 -DriveLetter 'D' -Folder 'Work\KiroWorkspace' -WhatIf
.\Install-KiroWorkspace.ps1 -DriveLetter 'D' -Folder 'Work\KiroWorkspace'
```

The example installs to `D:\Work\KiroWorkspace`. For a folder directly on C, use `-DriveLetter 'C' -Folder 'KiroWorkspace'`. Set defaults in the script's first two parameters if you prefer. The installer copies the workspace without merging into an existing folder. If your work PC blocks the script, follow your department's approved script process.

## 2. Open Kiro

In the approved Kiro IDE, open the destination folder using File > Open Folder. Use your corporate account and configuration. Start a fresh session with the relevant agent from the agent picker. Keep Supervised mode for coordinator work. The configurations target IDE 1.x and CLI V3. If you already use CLI V3, run from the installed folder:

```powershell
kiro-cli --v3 --agent gc-strategic-advisor
```

In CLI chat, `/agent` opens the agent picker and `/help` lists commands. See the [Kiro agent configuration reference](https://kiro.dev/docs/custom-agents/configuration-reference/) and [CLI commands](https://kiro.dev/docs/cli/reference/cli-commands/).

Use departmental material only within the authorized data and workflow scope. Start with the supplied fictional files. A local folder is a storage choice and does not change how Kiro processes prompts. The advisor uses supplied evidence and has no web tools. Provide approved policy extracts or references if you want a policy assessment.

## 3. Ask the Chief of Staff to call in the MBA

Start a fresh session with `chief-of-staff`. Say "Call in the MBA" for an independent review. The Chief of Staff also routes the work to `gc-strategic-advisor` when you flag an unfamiliar decision, material evidence is unresolved, or the trade-off could materially change cost, risk, obligations or accountability.

Try this with the fictional files:

> For demo-project, call in the MBA. I am new to setting an after-hours outage notification commitment. Use only projects/demo-project/inbox/2026-11-09-fictional-mou-meeting.md and projects/demo-project/source-documents/demo-mou.md. Compare the current four-hour clause with one hour during staffed hours and one hour around the clock. My initial preference is one hour around the clock. Ask the advisor for an independent view first, then share my preference for reconciliation. Keep the result in chat.

Look for the MBA review status, referral trigger, options, differences and next decision. The fictional sources do not establish staffing, costs or after-hours feasibility. If delegation is unavailable, the Chief of Staff marks the review pending. Open `gc-strategic-advisor` in a fresh session and request Independent MBA Review using the decision and source facts. If you have a preferred option, share it after the first assessment and request MBA Reconciliation. Return the reviewed handoff to the Chief of Staff.

### Update an installed workspace

Back up your existing versions of `.kiro/agents/chief-of-staff.json` and `.kiro/agents/gc-strategic-advisor.json`. Copy these two files from this ZIP into the same paths in your workspace. If you customized either profile, merge the new prompt paragraphs into your version. Copy this README if you want the new commands in your workspace. Start a fresh Kiro session after the update.

## 4. Run the MOU example

The capitalized names below are prompts to paste into Kiro chat.

**ADVISORY REVIEW.** Select `gc-strategic-advisor` and paste:

> ADVISORY REVIEW for demo-project. Read only projects/demo-project/inbox/2026-11-09-fictional-mou-meeting.md and projects/demo-project/source-documents/demo-mou.md. Review the one-hour Priority 1 change. Return the standard advisory handoff for MOU UPDATE. Keep the effective date and Priority 2 open.

Expect a recommendation and a decision status of **Agreed in principle** for Priority 1. Confirm the status, decision owner and evidence before passing the handoff onward.

**MOU UPDATE.** Start a fresh session with `chief-of-staff` and paste:

> MOU UPDATE for demo-project. Use the same two files named below and the reviewed handoff I supply. Return the current and proposed text for section 4.2, source date and filename, and open items. Keep the review in chat. Wait for my approval before creating any file.

Append the same two paths and the reviewed handoff. The coordinator can route the clause proposal to the document specialist and quality reviewer. If delegation is unavailable in your version, run the request with `document-specialist`, then give the proposal and sources to `quality-reviewer` in a separate session.

After reviewing the exact wording, apply approved edits to a separate Word copy with Track Changes. For a live .docx, supply an authorized exact text export of the relevant clause if Kiro cannot read the source. This package produces a clause proposal. Use your existing Word and MOU approval process for the official amendment.

For another task, select `chief-of-staff`, name one project, name the files, and request the deliverable in plain language. Keep source documents and project registers unchanged until a separate authorized step. The original technical briefing example is still in `projects/demo-project`.
