# Fictional meeting notes

Meeting date: November 9, 2026
Project: demo-project
Topic: Cloud Operations MOU, section 4.2

The service team and departmental operations representatives agreed in principle to change the Priority 1 outage notification deadline from four hours to one hour after confirmation. The service team sends the notice to the departmental operations lead.

Extending the same deadline to Priority 2 was discussed and deferred. The group did not set an effective date or record authorization to draft or formally amend the MOU.
