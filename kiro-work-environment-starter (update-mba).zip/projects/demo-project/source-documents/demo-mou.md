# Cloud Operations MOU excerpt

Fictional source for demonstration only.

## 4.2 Priority 1 outage notification

The service team will notify the departmental operations lead within four hours of confirming a Priority 1 outage.
