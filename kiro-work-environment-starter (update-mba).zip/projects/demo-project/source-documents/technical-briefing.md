# SYNTHETIC Technical Briefing
## Proposed architecture
Current solution remains in place pending formal review. No migration approved.
## Next steps
Investigate service alternatives and determine budget and security implications.
